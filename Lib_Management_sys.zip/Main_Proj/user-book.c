#include"lib_header.h"
 

IR* Book_ID(IR*);
IR* user_ID(IR*);
IR* user_name(IR*);




IR* search_record(IR *ptr)
{
        char ch;
	IR* last;
LABEL:

       printf("\n");

       printf("+--------------------------------------------------------------+\n");
       printf("|           SELECT THE WAY OF CHOOSING THE Book                |\n");
       printf("+--------------------------------------------------------------+\n");
       printf("|                [R/r] To search using Book ID                 |\n");
       printf("|                [U/u] To search using User ID	               |\n");
       printf("|                [N/n] To search using User name 	       |\n");
       printf("|                [E/e] To exit to main menu                    |\n");
       printf("+--------------------------------------------------------------+\n");

       printf("\n");
       printf("   choose your option: ");
       scanf(" %c",&ch);
       if((ch=='R')||(ch=='r'))
       {
       	       last=Book_ID(ptr);
	       return last;
       }
       else if((ch=='U')||(ch=='u'))
       {
       	       last=user_ID(ptr);
	       return last;
       }	       
       else if((ch|32)=='n')
       {
	       last=user_name(ptr);
	       return last;
       }
       else if((ch=='E')||(ch=='e'))
                return NULL;
       else
       {
               printf("\n       choose correct option...        \n\n\n");
               goto LABEL;
       }
}

IR* Book_ID(IR *ptr)
{
        int id,count=0;
        char ch;
        
        printf("Enter the Book ID for search: ");
        scanf("%d",&id);
        IR *temp =ptr,*last;
	//IR *temp=ptr;
                        printf("****************************************\n");
        while(temp!=0)
        {
                if(temp->BookID==id)
                {
                        printf("* %-10d | %-10d | %-10s *\n",temp->BookID,temp->UserID,temp->User);
                        count++;
                        last=temp;
                }
                temp = temp->next;
        }
                        printf("****************************************\n");
        printf("\n\n");
        if(count>1)
                user_ID(ptr);
        else if(count==1)
                return last;
        else
        {
                printf("\nNo Matching data found.....\n");
                return NULL;
        }
}

IR* user_ID(IR *ptr)
{
        int id;
        char ch;
        
        printf("Enter the User ID for search: ");
        scanf("%d",&id);
        IR *temp =ptr,*last;
        while((temp!=0)&&(temp->UserID!=id ))
        temp = temp->next;

        if(temp==0)
        {
 	       printf("\nNo Matching Data found ....\n");
               return NULL;
        }
        else 
               return temp;
}




IR* user_name(IR *ptr)
{
        int count=0,roll;
        IR *last=NULL;
        char ch[20];

        printf("Enter the user name for search: ");
        scanf("%s",ch);
        IR *temp=ptr;
                        printf("****************************************\n");
        while(temp!=0)
        {
                if(strcmp(temp->User,ch)==0)
                {
                        printf("* %-10d | %-10d | %-10s *\n",temp->BookID,temp->UserID,temp->User);
		        count++;
                        last=temp;
                }
                temp = temp->next;
        }
                        printf("****************************************\n");
        printf("\n\n");
        if(count>1)
                Book_ID(ptr);
        else if(count==1)
                return last;
        else
	{
                printf("\nNo Matching data found.....\n");
		return NULL;
	}

}






