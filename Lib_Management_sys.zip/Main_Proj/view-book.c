#include"lib_header.h"

void view_book(BK *ptr)
{

	int i=1;
	printf("\n");
        printf("********************************************************************************\n");
        printf("*                            **** Book  List  ****                             *\n");
        printf("********************************************************************************\n");
        printf("* Sl.no * Book ID    * Book Name             * Author Name         * Quantity  *\n");
        printf("********************************************************************************\n");
        while(ptr!=0){
        printf("* %d    | %-4d       | %-15s        | %-10s          | %-6d    *\n",i++,ptr->Book_ID,ptr->Book,ptr->Author,ptr->Qty);
        ptr=ptr->next;
        }
        printf("********************************************************************************\n");
}

