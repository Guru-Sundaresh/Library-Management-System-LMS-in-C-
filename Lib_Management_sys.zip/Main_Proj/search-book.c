#include"lib_header.h"
 

BK* book_ID(BK*);
BK* book_name(BK*);
BK* author_name(BK*);




BK* search_book(BK *ptr)
{
        char ch;
	BK* last;
LABEL:

       printf("\n");

       printf("+--------------------------------------------------------------+\n");
       printf("|           SELECT THE WAY OF CHOOSING THE Book                |\n");
       printf("+--------------------------------------------------------------+\n");
       printf("|                [R/r] To search using Book ID                 |\n");
       printf("|                [N/n] To search using Book name               |\n");
       printf("|                [A/a] To search using Author name             |\n");
       printf("|                [E/e] To exit to main menu                    |\n");
       printf("+--------------------------------------------------------------+\n");

       printf("\n");
       printf("   choose your option: ");
       scanf(" %c",&ch);
       if((ch=='R')||(ch=='r'))
       {
       	       last=book_ID(ptr);
	       return last;
       }
       else if((ch=='N')||(ch=='n'))
       {
       	       last=book_name(ptr);
	       return last;
       }	       
       else if((ch|32)=='a')
       {
	       last=author_name(ptr);
	       return last;
       }
       else if((ch=='E')||(ch=='e'))
                return NULL;
       else
       {
               printf("\n       choose correct option...        \n\n\n");
               goto LABEL;
       }
}

BK* book_ID(BK *ptr)
{
        int id;
        char ch;
        
        printf("Enter the Book ID for search: ");
        scanf("%d",&id);
        BK *temp =(ptr),*last;
        while((temp!=0)&&(temp->Book_ID!=id ))
        temp = temp->next;

        if(temp==0)
        {
 	       printf("\nNo Matching Data found ....\n");
               return NULL;
        }
        else 
               return temp;
}

BK* book_name(BK *ptr)
{
        int count=0,roll;
        BK *last=NULL;
        char ch[20];

        printf("Enter the Book name for search: ");
        scanf(" %[^\n]",ch);
        BK *temp=(ptr);
                        printf("***************************************************\n");
        while(temp!=0)
        {
                if(strcmp(temp->Book,ch)==0)
                {
                        printf("* %-10d | %-10s | %-10s | %-10d *\n",temp->Book_ID,temp->Book,temp->Author,temp->Qty);
		        count++;
                        last=temp;
                }
                temp = temp->next;
        }
                        printf("***************************************************\n");
        printf("\n\n");
        if(count>1)
                book_ID(ptr);
        else if(count==1)
                return last;
        else
                printf("\nNo Matching data found.....\n");
}

BK* author_name(BK *ptr)
{
        int count=0,roll;
        BK *last=NULL;
        char ch[20];

        printf("Enter the Author name for search: ");
        scanf(" %[^\n]",ch);
        BK *temp=(ptr);
                        printf("***************************************************\n");
        while(temp!=0)
        {
                if(strcmp(temp->Author,ch)==0)
                {
                        printf("* %-8d     | %-8s        | %-8s       |%-8d     *\n",temp->Book_ID,temp->Book,temp->Author,temp->Qty);
		        count++;
                        last=temp;
                }
                temp = temp->next;
        }
                        printf("***************************************************\n");
        printf("\n\n");
        if(count>1)
                book_ID(ptr);
        else if(count==1)
                return last;
        else
                printf("\nNo Matching data found.....\n");
}






