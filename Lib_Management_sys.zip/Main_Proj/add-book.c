#include"lib_header.h"


void add_book(BK **ptr)
{
	BK *new=(BK*)malloc(sizeof(BK));
	printf("Enter the Book ID: ");
	scanf("%d",&new->Book_ID);
        printf("Enter the Book Name: ");
	scanf(" %[^\n]",new->Book);
	printf("Enter the Author Name: ");
	scanf(" %[^\n]",new->Author);
	printf("Enter no. of copies arrived : ");
	scanf("%d",&new->Qty);
	
		new->prev=0;
	 	new->next=0;
			
	if((*ptr)==NULL)
		(*ptr) = new;
	else
	{
		BK *last=(*ptr);
		while(last->next!=0) 
		{
			//last->roll=++x;
			last=last->next;
		}
		last->next=new;
		new->prev=last;
		
	}

	printf("\n	Book Added Successfully...\n");
}	

