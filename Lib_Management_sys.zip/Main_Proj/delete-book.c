#include"lib_header.h"

void remove_book(BK**ptr)
{
	BK *temp=search_book(*ptr);
	BK *last;
	if(temp!=NULL)
	{
		if(temp==(*ptr))
		{
			(*ptr)=temp->next;
			(*ptr)->prev=temp->prev;
		}
		else 
		{
			last=temp->prev;
			last->next=temp->next;
			if(temp->next!=0)
			{
				last=temp->next;
				last->prev=temp->prev;
			}
		}
		free(temp);
		temp=NULL;
	}
	return;

}
	
		

			
			


