#include"lib_header.h"

void save_record(IR *ptr) 
{
	if(ptr==NULL)
		return;
	
	IR *temp=ptr;
	int i=1;
	FILE *file=fopen("Rec_data","w");
	fprintf(file,"********************************************************************************************************************\n");
        fprintf(file,"*                                        **** Issue Book  List  ****                                               *\n");
        fprintf(file,"********************************************************************************************************************\n");
        fprintf(file,"* Issue ID  * Book ID    * User ID * User Name            * Issue Date     * Due Date     * Return Date     * Fine *\n");
        fprintf(file,"********************************************************************************************************************\n");
        while(ptr!=0){
        fprintf(file,"* %d        | %d         | %d      | %-12s         | %-4s     | %-6s   | %-6s          | %d    *\n",ptr->IssueID,ptr->BookID,ptr->UserID,ptr->User,ptr->Idate,ptr->Ddate,ptr->Rdate,ptr->Fine);
        ptr=ptr->next;
        }
        fprintf(file,"********************************************************************************************************************\n");
        fclose(file);

	FILE *fp=fopen("record_file","w");
	while(temp)
	{
	fprintf(fp,"%d\n%d\n%d\n%s\n%s\n%s\n%s\n%d\n",temp->IssueID,temp->BookID,temp->UserID,temp->User,temp->Idate,temp->Ddate,temp->Rdate,temp->Fine);
	temp=temp->next;
	}
	fclose(fp);
	
//	printf("\nFile Saved Successfully....\n");
}




