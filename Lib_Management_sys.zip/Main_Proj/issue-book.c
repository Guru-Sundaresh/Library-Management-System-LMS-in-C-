#include"lib_header.h"

void issue_date(IR*);
void due_date(IR*);

void issue_book(IR **rec,BK *ptr)
{
	
	BK *temp=search_book(ptr);
	temp->Qty=temp->Qty-1;
	if(temp!=NULL)
	{
	IR *new=(IR*)malloc(sizeof(IR));
	new->prev=0;
	new->next=0;
	new->Fine=0;
	new->BookID=temp->Book_ID ;
	strcpy(new->Rdate,"-");
	issue_date(new);
	due_date(new);
	//new->Rdate=0;

	if((*rec)==NULL)
	{
		*rec=new;
		new->IssueID=1;
	}
	else
	{
		IR *last=*rec;
		while(last->next!=0)
			last=last->next;
		last->next=new;
		new->prev=last;
		new->IssueID=last->IssueID+1;
	}	



	printf("Enter the User ID and User Name: ");
	scanf("%d %[^\n]",&new->UserID,new->User);
	}
	return;
}

void issue_date(IR *ptr)
{
	time_t t;      
	struct tm *date;       
	time(&t);   
	date = localtime(&t);  

	sprintf(ptr->Idate,"%02d-%02d-%04d",date->tm_mday,date->tm_mon + 1,date->tm_year + 1900);

}


void due_date(IR *ptr)
{
	time_t t;      
	struct tm *date;       
	time(&t);   
	date = localtime(&t); 

	switch(date->tm_mon+1)
	{
	case 1:case 3:case 5:case 7:case 8:case 10: case 12:
		if(date->tm_mday > 24)
		{
			int day=1;
			for(int i=1;i<8;i++)
				if(date->tm_mday>31)
					date->tm_mday=day++;
				else
					date->tm_mday+=i;
		}
		else
			date->tm_mday+=7;
		break;
	case 2:
		if(((date->tm_year + 1900)%4)==0)
		{
			if(date->tm_mday >22)
			{
				int day =1;	
				for(int i=1;i<8;i++)
					if(date->tm_mday>29)
						date->tm_mday=day++;
					else
						date->tm_mday+=i;
			}
			else
				date->tm_mday+=7;
		}
		else
		{
			if(date->tm_mday >21)
			{
				int day =1;	
				for(int i=1;i<8;i++)
					if(date->tm_mday>28)
						date->tm_mday=day++;
					else
						date->tm_mday+=i;
			}
			else
				date->tm_mday+=7;
		}
		break;
	case 4:case 6:case 9:case 11:
		if(date->tm_mday > 23)
                {
                        int day=1;
                        for(int i=1;i<8;i++)
                                if(date->tm_mday>30)
                                        date->tm_mday=day++;
                                else
                                        date->tm_mday+=i;
                }
                else
                        date->tm_mday+=7;
                break;
	}

	sprintf(ptr->Ddate,"%02d-%02d-%04d",date->tm_mday,date->tm_mon + 1,date->tm_year + 1900);

}






