#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <unistd.h>
#include<time.h>

typedef struct Books
{
	struct Books *prev;
        int Book_ID;
        char Book[20];
        char Author[20];
	int Qty;
        struct Books *next;
}BK;

typedef struct Record
{
	struct Record *prev;
	int IssueID;
	int BookID;
	int UserID;
	char User[20];
	char Idate[15];
	char Ddate[15];
	char Rdate[15];
	int Fine;
	struct Record *next;
}IR;



void add_book(BK**);
void remove_book(BK**);
void update_book(BK *);
void save_book(BK*);
BK* search_book(BK*);
void view_book(BK *);
void issue_book(IR **,BK *);
void list_record(IR *);
void return_book(IR *,BK *);
void save_record(IR *);
IR* search_record(IR *);


