#include"lib_header.h"

void update_book(BK *ptr)
{

	BK *temp=search_book(ptr);

	if(temp!=NULL)
	{

	char op;
LABEL:
	printf("\n");
	printf("+--------------------------------------------------------------+\n");
	printf("|           	   Field of Modification                       |\n");
	printf("+--------------------------------------------------------------+\n");
	printf("|                      [I/i] : Book ID                         |\n");
	printf("|                      [N/n] : Book Name                       |\n");
	printf("|                      [A/a] : Author Name                     |\n");
	printf("|                      [Q/q] : Quantity                        |\n");
	printf("|                      [E/e] : Exit	                       |\n");
	printf("+--------------------------------------------------------------+\n");


	printf("which data field you want to modify: ");
	scanf(" %c",&op);
	
	switch(op|32)
	{
		case 'i':
			printf("Enter the new Book ID to update: ");
			scanf("%d",&temp->Book_ID);
			break;
		case 'n':
			printf("Enter the new name of the Book to update: ");
			scanf(" %[^\n]",temp->Book);
			break;
		case 'a':
			printf("Enter the new name of the Author to update: ");
			scanf(" %[^\n]",temp->Author);
			break;
		case 'q':
			printf("Enter the Quantity of the book to update: ");
			scanf("%d",&temp->Qty);
			break;
		case 'e':
			return;
		default:
			printf("\n Invalid Field of modification ..");
			goto LABEL;
	}
	printf("\n Modified Successfully...\n");
	}
	return;
}	
	


