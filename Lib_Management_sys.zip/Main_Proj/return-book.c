#include"lib_header.h"

void return_book(IR *rec,BK *ptr)
{
	IR *temp=search_record(rec);
	
	if(temp==NULL)
		return;

	while(ptr->Book_ID!=temp->BookID)
	ptr=ptr->next;
	
	ptr->Qty=ptr->Qty+1;	

	time_t t;
        struct tm *date;
        time(&t);
        date = localtime(&t);

        sprintf(temp->Rdate,"%02d-%02d-%04d",date->tm_mday,date->tm_mon + 1,date->tm_year + 1900);

	
		int date1,date2,mon1,mon2,mon,d;
		date1=(((temp->Ddate[0]-48)*10)+(temp->Ddate[1]-48));
		date2=(((temp->Rdate[0]-48)*10)+(temp->Rdate[1]-48));
		mon1=(((temp->Ddate[3]-48)*10)+(temp->Ddate[4]-48));
		mon2=(((temp->Rdate[3]-48)*10)+(temp->Rdate[4]-48));
		
		if((mon1==mon2)&&(date2<date1))
			return;
		else
		{

		mon=mon2-mon1;
			
		if(mon==0)
		{
			d=date2-date1;
			temp->Fine=d*5;
		}
		else 
		{

			int i,count,x;
			switch(mon1)
			{
				case 1:x=31;break;
				case 2:x=28;break;
				case 3:x=31;break;
				case 4:x=30;break;
				case 5:x=31;break;
				case 6:x=30;break;
				case 7:x=31;break;
				case 8:x=31;break;
				case 9:x=30;break;
				case 10:x=31;break;
				case 11:x=30;break;
				case 12:x=31;break;
			}
			for(i=date1++;;i++)
			{
				if(i==x)
				{
					i=0;
					if(x=30)
						x=31;
					else
						x=30;
				}
				if((mon1==mon2)&&(i==date2))
						break;
				count++;
			}
			temp->Fine=count*5;
							
		}
		return;

	}
}
		




