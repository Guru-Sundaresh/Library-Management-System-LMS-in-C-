#include"lib_header.h"

void save_book(BK *ptr) 
{
	BK *temp=ptr;
	int i=1;
	FILE *file=fopen("Lib_data","w");
	fprintf(file,"********************************************************************************\n");
        fprintf(file,"*                            **** Book  List  ****                             *\n");
        fprintf(file,"********************************************************************************\n");
        fprintf(file,"* Sl.no * Book ID    * Book Name             * Author Name         * Quantity  *\n");
        fprintf(file,"********************************************************************************\n");
        while(ptr!=0){
        fprintf(file,"* %d    | %-4d       | %-15s        | %-10s          | %-6d    *\n",i++,ptr->Book_ID,ptr->Book,ptr->Author,ptr->Qty);
        ptr=ptr->next;
        }
        fprintf(file,"********************************************************************************\n");
	fclose(file);

	FILE *fp=fopen("load_file","w");
	while(temp)
	{
	fprintf(fp,"%d\n%s\n%s\n%d\n",temp->Book_ID,temp->Book,temp->Author,temp->Qty);
	temp=temp->next;
	}
	fclose(fp);
	
//	printf("\nFile Saved Successfully....\n");
}




