#include"lib_header.h"

void load_book(BK** );
void load_record(IR** );

int main()
{
	BK *hptr=NULL;
	IR *rec=NULL;
	char op,ch;
	load_book(&hptr);
	load_record(&rec);
	system("clear");
	
//LABEL:
	do
	{
	printf("\n");	
	printf("			**********************************************************\n");	
	printf("			*  	      **** BOOK MANAGEMENT MENU ****		 *\n");	
	printf("			**********************************************************\n");
	printf("			|	    [A/a] : Add New Book			 |\n");
	printf("			+--------------------------------------------------------+\n");
	printf("			|	    [D/d] : Remove a Book			 |\n");
	printf("			+--------------------------------------------------------+\n");
	printf("			|	    [U/u] : Update Book Details			 |\n");
	printf("			+--------------------------------------------------------+\n");
	printf("			|	    [B/b] : Search Book				 |\n");
	printf("			+--------------------------------------------------------+\n");
	printf("			|	    [V/v] : View All Books			 |\n");
	printf("			+--------------------------------------------------------+\n");
	printf("			|	    [I/i] : Issue Book				 |\n");
	printf("			+--------------------------------------------------------+\n");
	printf("			|	    [R/r] : Return Book				 |\n");
	printf("			+--------------------------------------------------------+\n");
	printf("			|	    [L/l] : List Issued Books			 |\n");
	printf("			+--------------------------------------------------------+\n");
	printf("			|	    [S/s] : Save				 |\n");
	printf("			+--------------------------------------------------------+\n");
	printf("			|	    [E/e] : Exit				 |\n");
	printf("			**********************************************************\n");

	printf("\n Enter your choice: ");
	scanf(" %c",&op);
	
	switch(op|32)
	{
		case 'a':
			add_book(&hptr);
			break;
		case 'd':
			remove_book(&hptr);
			break;
		case 'u':
			update_book(hptr);
			break;
		case 'b':
			search_book(hptr);
LABEL:
                        printf("Press Enter to Continue..\n");
                        getchar();
                        ch=getchar();
                        if(ch=='\n')
                                break;
                        else
                                goto LABEL;
		case 'v':
			view_book(hptr);
LABEL1:
                        printf("Press Enter to Continue..\n");
                        getchar();
                        ch=getchar();
                        if(ch=='\n')
                                break;
                        else
                                goto LABEL1;
		case 'i':
			issue_book(&rec,hptr);
			break;
		case 'r':
			return_book(rec,hptr);
		        list_record(rec);
LABEL3:	
                        printf("Press Enter to Continue..\n");
                        getchar();
                        ch=getchar();
                        if(ch=='\n')
                                break;
                        else
                                goto LABEL3;

			break;
		case 'l':
			list_record(rec);
LABEL2:
                        printf("Press Enter to Continue..\n");
                        getchar();
                        ch=getchar();
                        if(ch=='\n')
                                break;
                        else
                                goto LABEL2;
		case 's':
			save_book(hptr);
			save_record(rec);
			printf("\nFile Saved Successfully....\n");
			break;
		case 'e':
			printf("**********************************************************\n");
			printf("* 	[S/s] : Save and Exit                            *\n");
			printf("*	[E/e] : Exit without Saving			 *\n");
			printf("**********************************************************\n");
			
			printf("	Enter your option: ");
			scanf(" %c",&ch);
			if((ch|32)=='s')
			{	
				save_book(hptr);
				save_record(rec);
			}
			return 0;
		default:
			printf("\n Choose correct option from the list...\n");
			sleep(3);
	}
	system("clear");
	}while(1);
}

void load_book(BK **ptr)
{

	
	
	FILE *fp=fopen("load_file","r");
	if(fp==NULL)
	return;
	
	
		
	while(1)
	{
	BK *new=(BK *)malloc(sizeof(BK));
	
	if(fscanf(fp,"%d",&new->Book_ID)!=1)
	{
		free(new);
		break;
	}
	fscanf(fp," %[^\n]",new->Book);
	fscanf(fp," %[^\n]",new->Author);
	fscanf(fp,"%d",&new->Qty);
	new->prev=0;
	new->next=0;
	if((*ptr)==NULL)
		*ptr=new;
	else
	{
		BK *last=*ptr;
		while(last->next!=0)
			last=last->next;

		last->next=new;
		new->prev=last;
	}
	}

	fclose(fp);
	return;
}

void load_record(IR **ptr)
{
	 

        FILE *fp=fopen("record_file","r");
        if(fp==NULL)
        return;



        while(1)
        {
        IR *new=(IR *)malloc(sizeof(IR));

        if(fscanf(fp,"%d",&new->IssueID)!=1)
        {
                free(new);
                break;
        }
        fscanf(fp,"%d",&new->BookID);
        fscanf(fp,"%d",&new->UserID);
        fscanf(fp," %[^\n]",new->User);
        fscanf(fp,"%s",new->Idate);
        fscanf(fp,"%s",new->Ddate);
        fscanf(fp,"%s",new->Rdate);
        fscanf(fp,"%d",&new->Fine);
        new->prev=0;
        new->next=0;
        if((*ptr)==NULL)
                *ptr=new;
        else
        {
                IR *last=*ptr;
                while(last->next!=0)
                        last=last->next;

                last->next=new;
                new->prev=last;
        }
        }

        fclose(fp);
        return;
}






				       







	 

